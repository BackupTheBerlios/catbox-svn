/*****************************************************************/
/* Dateiname   : ServerGrafikSenden.c                            */
/* Beschreibung: Server-Programm                                 */
/*               Analysiert einen HTTP-GET-Befehl und versucht   */
/*               eine Grafik-Datei oder eine HTML-Datei zu senden*/
/*****************************************************************/

#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>

int main()
 {
  int server_socket, client_socket;
  int anzahl, laenge, dateigroesse;
  struct sockaddr_in serverinfo, clientinfo;
  char zeichen;
  char empfangen[1000];
  char senden[1000];
  char *position1, *position2;
  char dateiname[100];
  char text_http_ok[] = "HTTP/1.0 200 OK\r\n";
  char text_http_fehler[] ="HTTP/1.1 501 Not Implemented\r\n\r\n";
  char text_http_range[] = "Accept-Ranges: bytes\r\n";
  char text_http_length[] = "Content-Length: ";
  char text_dateigroesse[20];
  char text_http_typ_png[] = "Content-Type: image/png\r\n";
  char text_http_typ_html[] = "Content-Type: text/html\r\n";
  char text_leerzeile[] = "\r\n";
  char text_html_anfang[] = "<HTML><BODY>";
  char text_html_ende[] = "</BODY></HTML>";
  FILE *datei;

  server_socket = socket(AF_INET, SOCK_STREAM, 0);

  serverinfo.sin_family = AF_INET;
  serverinfo.sin_addr.s_addr = htonl(INADDR_ANY);
  serverinfo.sin_port = htons(5000);
  laenge = sizeof(serverinfo);

  bind(server_socket, (struct sockaddr *)&serverinfo, laenge);
  listen(server_socket, 3);

  while (1)
   {
    printf("\n Der Server wartet...");
    fflush(stdout);

    client_socket = accept(server_socket, (struct sockaddr *)&clientinfo, &laenge);

    printf("\n Verbindung mit %s",inet_ntoa(clientinfo.sin_addr));

    anzahl = read(client_socket,empfangen,sizeof(empfangen));
    empfangen[anzahl]=0;
 
    if (position1 = strstr(empfangen,"GET"))
     {
      if (position2 = strstr(empfangen,"HTTP"))
       {
        laenge = position2 - position1 - 6;
        strncpy(dateiname,position1+5,laenge);
        dateiname[laenge]=0;
        printf("\n GET Befehl f�r Datei %s gefunden",dateiname);
        datei = fopen(dateiname,"rb");
        if (datei==NULL)
      	{
	       printf("\n Datei existiert nicht\n");

          strcpy(senden,text_http_ok);
          strcat(senden,text_html_anfang);
          strcat(senden,"<br>Datei existiert nicht");
          strcat(senden,text_html_ende);
 
          write(client_socket,senden,strlen(senden));
	      }
	     else  
	      {
          dateigroesse = -1;
 	       do
	        {
            fgetc(datei);
            dateigroesse++;
	        } while (!feof(datei));

          printf("\n Dateigr��e = %d Bytes",dateigroesse);
          sprintf(text_dateigroesse,"%d\r\n",dateigroesse);

          strcpy(senden,text_http_ok);
          strcat(senden,text_http_range);
          strcat(senden,text_http_length);
          strcat(senden,text_dateigroesse);

          if (strstr(dateiname,".png"))
           {
            strcat(senden,text_http_typ_png);
           }
          else
           {
            strcat(senden,text_http_typ_html);
           }

          strcat(senden,text_leerzeile);

          printf("\n Server: sende Paketkopf:\n%s",senden);
          write(client_socket,senden,strlen(senden));

          printf("Server: sende Datei: %s\n",dateiname);

          rewind(datei);
          do
	        {
	         zeichen = fgetc(datei);
	         if (!feof(datei))
	          {
	           write(client_socket,&zeichen,1);
	          }	
	        } while (!feof(datei));
          fclose(datei);
	      }
       }
      else
       {
        printf("\nDer HTTP-Parser hat keinen HTTP-Befehl gefunden");
        write(client_socket,text_http_fehler,strlen(text_http_fehler));
       }
     }
    else
     {
      printf("\nDer HTTP-Parser hat keinen GET-Befehl gefunden");
      write(client_socket,text_http_fehler,strlen(text_http_fehler));
     }
    close(client_socket);
   }
 }







