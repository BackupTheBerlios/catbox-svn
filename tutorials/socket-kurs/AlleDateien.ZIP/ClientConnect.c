/*****************************************************************/
/* Dateiname   : ClientConnect.c                                 */
/* Beschreibung: Client-Programm                                 */
/*               baut eine TCP-Verbindung zu einem Server auf    */
/*****************************************************************/
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
int main()
  {
   int socket_nummer;
   int laenge;
   struct sockaddr_in adressinfo;
   int ergebnis;
   socket_nummer = socket(AF_INET, SOCK_STREAM, 0);
   adressinfo.sin_family = AF_INET;
   adressinfo.sin_addr.s_addr = inet_addr("127.0.0.1");
   adressinfo.sin_port = htons(80);
   laenge = sizeof(adressinfo);
   ergebnis = connect(socket_nummer, (struct sockaddr *)&adressinfo, laenge);
   if (ergebnis == 0)
     {
      printf("\nVerbindungsaufbau erfolgreich");
     }
   else
     {
      perror("Fehler beim Verbindungsaufbau: ");
     }
   close(socket_nummer);
   printf("\n\n");
  }
