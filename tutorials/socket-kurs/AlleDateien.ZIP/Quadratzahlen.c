/*****************************************************************/
/* Dateiname   : Quadratzahlen.c                                 */
/* Beschreibung: Beispielprogramm                                */
/*               gibt die Quadratzahlen von 1 bis 20 aus         */
/*****************************************************************/
/* Die Quadratzahlen von 1 bis 20 ausgeben */

#include <stdio.h>

main()
  {
   int index;   
   int zahlen[20];

   for(index=0; index<20; index++)
    {
     zahlen[index] = (index+1)*(index+1);
     printf("\n Die Zahl %d zum Quadrat",index+1);
     printf(" ist %d", zahlen[index]);
    }
  }
