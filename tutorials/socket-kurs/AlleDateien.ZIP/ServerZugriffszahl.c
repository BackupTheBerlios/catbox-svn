/*****************************************************************/
/* Dateiname   : ServerZugriffszahl.c                            */
/* Beschreibung: Server-Programm                                 */
/*               Sendet Web-Seite mit Zugriffszahl �ber Port 5000*/
/*               mit Endlos-Schleife f�r beliebig viele Zugriffe */
/*****************************************************************/


#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>

main()
{
 int server_socket, neuer_socket;
 int laenge, anzahl;
 int zaehler = 0;
 struct sockaddr_in serverinfo, clientinfo;
 char empfangene_zeichen[1000];
 char web_seite[1000];

 unsigned short int portnummer = 5000;
 char ip_adresse[] = "INADDR_ANY";

 printf("\n Server: socket()...");

 server_socket = socket(AF_INET, SOCK_STREAM, 0);
 
 serverinfo.sin_family = AF_INET;
 serverinfo.sin_addr.s_addr = htonl(INADDR_ANY);
 serverinfo.sin_port = htons(portnummer);
 laenge = sizeof(serverinfo);

 printf("\n Server: bind()...");
 
 bind(server_socket, (struct sockaddr *)&serverinfo, laenge);

 printf("\n Server: listen()...");
 printf("\n Server mit IP %s",ip_adresse);
 printf(" an Port %d wartet...",portnummer);

 listen(server_socket, 3);

 while(1)
   {

    printf("\n Server: accept()...");
 
    neuer_socket = accept(server_socket, (struct sockaddr *)&clientinfo, &laenge);
 
    printf("Verbindung mit %s",inet_ntoa(clientinfo.sin_addr));
 
    anzahl = read(neuer_socket,empfangene_zeichen,sizeof(empfangene_zeichen));
    empfangene_zeichen[anzahl]=0;

    printf("\n\n Server: empfangen: \n\n%s",empfangene_zeichen);

    zaehler++;

    sprintf(web_seite,"HTTP/1.1 200 OK\r\n\r\n\
    <html><body>\n\
      <br><br><br><br>\n\
      <center><h1>Sie sind Besucher Nr. %d</h1></center>\n\
    </body></html>",\
    zaehler);

    printf("\n\n Server: sende: \n\n%s",web_seite);
    write(neuer_socket,web_seite,strlen(web_seite));

    printf("\n\n Server: close()...");
   
    close(neuer_socket);
  }   
}


