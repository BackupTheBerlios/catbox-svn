/*****************************************************************/
/* Dateiname   : ServerAcceptEndlos.c                            */
/* Beschreibung: Server-Programm                                 */
/*               akzeptiert endlos TCP-Verbindungen an Port 5000 */
/*****************************************************************/

#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>

main()
{
 int server_socket, neuer_socket;
 int laenge;
 int verbindung_nummer = 1;
 struct sockaddr_in serverinfo, clientinfo;

 unsigned short int portnummer = 5000;
 char ip_adresse[] = "127.0.0.1";

 printf("\n Server: socket()...");

 server_socket = socket(AF_INET, SOCK_STREAM, 0);
 
 serverinfo.sin_family = AF_INET;
 serverinfo.sin_addr.s_addr = inet_addr(ip_adresse);
 serverinfo.sin_port = htons(portnummer);
 laenge = sizeof(serverinfo);

 printf("\n Server: bind()...");
 
 bind(server_socket, (struct sockaddr *)&serverinfo, laenge);

 printf("\n Server: listen()...");

 listen(server_socket, 3);

 while (1)
   {
    printf("\n Server mit IP %s",ip_adresse);
    printf(" an Port %d wartet",portnummer);
    printf(" auf Verbindung %d ...",verbindung_nummer);

    printf("\n Server: accept()...");
 
    neuer_socket = accept(server_socket, (struct sockaddr *)&clientinfo, &laenge);
 
    printf("Verbindung mit %s",inet_ntoa(clientinfo.sin_addr));

    printf("\n Server: close()...");
    close(neuer_socket);
    verbindung_nummer++;
  }  
 close(server_socket);
   
 printf("\n Serverprogramm beendet\n\n");
 return(0);
}

