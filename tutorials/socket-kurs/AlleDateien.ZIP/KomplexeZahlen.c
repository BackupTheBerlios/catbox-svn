/*****************************************************************/
/* Dateiname   : KomplexeZahlen.c                                */
/* Beschreibung: Beispielprogramm                                */
/*               Einlesen und Ausgeben von komplexen Zahlen      */
/*****************************************************************/

#include <stdio.h>

struct komplex
  {
   int realteil;
   int imaginaerteil;
  };

main()
  {
   struct komplex zahl;   
   printf("\n Bitte Realteil eingeben: ");
   scanf("%d",&zahl.realteil);
   printf("\n Bitte Imagin�rteil eingeben: ");
   scanf("%d",&zahl.imaginaerteil);

   printf("\n\n %d ", zahl.realteil);

   if (zahl.imaginaerteil > 0)
     {
      printf("+ j %d \n",zahl.imaginaerteil);
     }
   else if (zahl.imaginaerteil < 0)
     {
      printf("- j %d \n", -(zahl.imaginaerteil) );
     }
   }
