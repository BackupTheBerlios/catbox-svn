/*****************************************************************/
/* Dateiname   : ClientDateiAnfordern.c                          */
/* Beschreibung: Client-Programm                                 */
/*               fordert eine Datei vom Server an                */
/*****************************************************************/

#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>

main()
{
 int socket_nummer;
 int laenge;
 int anzahl;
 int ergebnis;
 struct sockaddr_in adresse;
 char empfangene_zeichen[65000];

 unsigned short int portnummer = 80;
 char ip_adresse[] = "127.0.0.1";
 char befehl[] = "GET /hallo.txt HTTP/1.1\r\nHost: PC\r\n\r\n";

 socket_nummer = socket(AF_INET, SOCK_STREAM, 0);
 
 adresse.sin_family = AF_INET;
 adresse.sin_addr.s_addr = inet_addr(ip_adresse);
 adresse.sin_port = htons(portnummer);
 laenge = sizeof(adresse);
 
 ergebnis = connect(socket_nummer, (struct sockaddr *)&adresse, laenge);
 
 printf("\n Verbindung zu IP %s",ip_adresse);
 printf(" an Port %d",portnummer);

 if (ergebnis == -1)
   {
    perror(" Keine Verbindung erfolgt: ");
   }
 else
   {
    printf("\n Verbindung erfolgt");
    printf(", sende HTTP-Befehl:\n\n%s",befehl);

    anzahl = write(socket_nummer, befehl, sizeof(befehl));
    printf(" es wurden %d Zeichen gesendet",anzahl);
 
    anzahl = read(socket_nummer, empfangene_zeichen, 
                  sizeof(empfangene_zeichen));
    empfangene_zeichen[anzahl]= '\0';
    
    printf("\n es wurden %d Zeichen empfangen:",anzahl);
    printf("\n\n%s",empfangene_zeichen);
   }  
   
 close(socket_nummer);  

 printf("\n Programm beendet\n\n");
}
