#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include "daemon.h"
/*!
@brief This is the lin#include <sys/types.h>
#include <sys/socket.h>ux-daemon for CatBox
@author Michael Durrer
@version 0.1
@date 20.03.2006
@bug No bugs known(,yet :)
@param 
@return
*/
int iInitNetwork(CatSocket *csSocket)
{
	return (1);
}
int main (int argc, char **argv[])
{
	CatSocket csSocket;
	printf("Starting CatBox-Daemon...\n");
	return (1);
} 
