#ifndef PARSER_H
#define PARSER_H
#endif
typedef struct parser
{
	char test;
} 
