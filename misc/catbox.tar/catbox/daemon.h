#ifndef DAEMON_H
#define DAEMON_H
#endif
typedef struct 
{
	int (*sConnect) (int);
}CatSocket;
typedef struct 
{
	char test;
}CatDaemon;

typedef struct
{
typedef struct
{
	int Farbe;
}Blume;
}CatApp;
