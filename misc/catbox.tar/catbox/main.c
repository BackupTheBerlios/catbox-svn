#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include "parser.h"

int main (int argc, char **argv[])
{
	return (1);
} 
